define( function() {
	return ( /\?/ );
} );
